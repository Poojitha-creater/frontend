# User Management REST API

This is a simple RESTful API for managing user data, built with Node.js, Express, and MongoDB.

## Features

- *Create:* Add a new user to the database.
- *Read:* Retrieve a list of all users or a single user by ID.
- *Update:* Modify an existing user's data.
- *Delete:* Remove a user from the database.

## Technologies Used

- *Node.js*: The JavaScript runtime environment.
- *Express.js*: A fast, unopinionated, minimalist web framework for Node.js.
- *Mongoose*: An elegant MongoDB object modeling tool for Node.js.
- *MongoDB Atlas*: A cloud-based database service to store user data.
- **dotenv**: A zero-dependency module that loads environment variables from a .env file.

## Getting Started

### Prerequisites

You need to have Node.js and npm installed. You also need a MongoDB Atlas account to get your database connection string.

### Installation

1.  *Clone the repository* (if applicable).
2.  *Install the dependencies* by running this command in your terminal:
    bash
    npm install
    

### Configuration

Create a .env file in the root of your project and add your MongoDB connection string and port number:

```env
PORT=3000
MONGO_URI=your_mongodb_connection_string