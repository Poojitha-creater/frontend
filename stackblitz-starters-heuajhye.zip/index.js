// index.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./db/db');
const userRoutes = require('./routes/userRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to the database
connectDB();

// Middleware
app.use(cors());
app.use(express.json()); // Parses incoming requests with JSON payloads

// API Routes
app.use('/api/users', userRoutes);

// Basic root route
app.get('/', (req, res) => {
  res.send('User Management API is running.');
});

// Start the server
app.listen(PORT, () => {
  console.log(Server is running on port ${PORT});
});