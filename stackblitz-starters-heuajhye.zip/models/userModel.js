// models/userModel.js
const mongoose = require('mongoose');

const geoSchema = new mongoose.Schema({
  lat: { type: String, required: true },
  lng: { type: String, required: true },
});

const addressSchema = new mongoose.Schema({
  city: { type: String, required: true },
  zipcode: { type: String, required: true },
  geo: { type: geoSchema, required: true },
});

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String },
  company: { type: String },
  address: { type: addressSchema, required: true },
});

module.exports = mongoose.model('User', userSchema);